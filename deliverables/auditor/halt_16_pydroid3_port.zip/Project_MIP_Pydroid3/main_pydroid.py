#!/usr/bin/env python3
"""
Project MIP: Standalone Pydroid 3 Quantitative Workstation
Directive: DIR-PROD-PYDROID3-PORT-01 (Standing Gate HALT-16)

Unified 1-tap mobile interactive terminal interface engineered for Pydroid 3.
Zero-compiler, pure Python + SQLite standard library architecture.
"""

import os
import sys
import time
import argparse
from pathlib import Path
from typing import Optional

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from pydroid_core.data_engine import (
    get_db_path,
    get_latest_date,
    get_universe_statistics,
)
from pydroid_core.scanner import PydroidScanner, format_screener_tearsheet
from pydroid_core.breadth import MarketBreadthEngine
from pydroid_core.sector_rotation import SectorRotationEngine
from pydroid_core.visuals import generate_matplotlib_dashboard, generate_plotly_tearsheet
from pydroid_core.telegram_sender import PydroidTelegramSender, format_telegram_alert
from pydroid_core.backtest import LightweightBacktester

# ANSI Styling
C_RESET = "\033[0m"
C_BOLD = "\033[1m"
C_GREEN = "\033[92m"
C_RED = "\033[91m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_CYAN = "\033[96m"
C_MAGENTA = "\033[95m"
C_GRAY = "\033[90m"


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def print_banner(latest_date: str):
    print(f"{C_BOLD}{C_CYAN}╔════════════════════════════════════════════════════════════════════╗{C_RESET}")
    print(f"{C_BOLD}{C_CYAN}║            PROJECT MIP — PYDROID 3 QUANTITATIVE DESK               ║{C_RESET}")
    print(f"{C_BOLD}{C_CYAN}║     Standalone Zero-Compiler Edition • Python 3.13 ARM64 Mobile    ║{C_RESET}")
    print(f"{C_BOLD}{C_CYAN}╚════════════════════════════════════════════════════════════════════╝{C_RESET}")
    print(f" {C_GRAY}Database: universe.db (Indexed SQLite) | Latest EOD: {C_BOLD}{latest_date}{C_RESET}")
    print(f"{C_GRAY}{'─' * 70}{C_RESET}")


def run_scanner_flow(interactive: bool = True):
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_YELLOW}⚡ RUNNING WEEKLY MOMENTUM SCANNER (FULL SUITE)...{C_RESET}\n")

    scanner = PydroidScanner(BASE_DIR)
    top_df, breadth, sectors, regime = scanner.run_scan(
        as_of_date=latest_date,
        top_n=20,
        export_csv=True
    )

    tearsheet = format_screener_tearsheet(top_df, breadth, sectors, regime, latest_date)
    print(tearsheet)

    print(f"\n{C_GREEN}✓ Scan completed successfully!{C_RESET}")
    print(f"  • Screener CSV: {BASE_DIR / 'reports' / 'screener_output_live.csv'}")
    print(f"  • Market Breadth: {BASE_DIR / 'reports' / 'market_breadth_live.json'}")
    print(f"  • Sector Rotation: {BASE_DIR / 'reports' / 'sector_rotation_live.json'}")

    if interactive:
        input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def run_telegram_preview():
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_BLUE}📱 PREVIEWING LIVE TELEGRAM ALERT PAYLOAD...{C_RESET}\n")

    reports_dir = BASE_DIR / "reports"
    screener_file = reports_dir / "screener_output_live.csv"
    breadth_file = reports_dir / "market_breadth_live.json"
    sector_file = reports_dir / "sector_rotation_live.json"

    if not (screener_file.exists() and breadth_file.exists() and sector_file.exists()):
        print(f"{C_YELLOW}⚠ Live data not cached. Running scanner first...{C_RESET}")
        scanner = PydroidScanner(BASE_DIR)
        top_df, breadth, sectors, regime = scanner.run_scan(as_of_date=latest_date, top_n=20)
    else:
        import json
        import pandas as pd
        top_df = pd.read_csv(screener_file)
        with open(breadth_file, "r", encoding="utf-8") as f:
            breadth = json.load(f)
        with open(sector_file, "r", encoding="utf-8") as f:
            sectors = json.load(f)
        scanner = PydroidScanner(BASE_DIR)
        regime = scanner.evaluate_regime(latest_date)

    msg = format_telegram_alert(top_df, breadth, sectors, regime, latest_date)
    sender = PydroidTelegramSender()
    sender.send_message(msg, dry_run=True)

    print(f"\n{C_GRAY}Message Length: {len(msg):,} characters (Telegram Limit: 4,096){C_RESET}")
    input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def run_telegram_dispatch():
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_MAGENTA}⚡ DISPATCHING LIVE TELEGRAM ALERT & DELIVERABLES...{C_RESET}\n")

    sender = PydroidTelegramSender()
    if not sender.is_configured():
        print(f"{C_RED}✗ Telegram credentials not configured in {BASE_DIR / '.env'}!{C_RESET}")
        print("Please edit .env and provide TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.")
        input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")
        return

    reports_dir = BASE_DIR / "reports"
    screener_file = reports_dir / "screener_output_live.csv"
    if not screener_file.exists():
        print(f"{C_YELLOW}Running scanner to generate latest deliverables...{C_RESET}")
        scanner = PydroidScanner(BASE_DIR)
        top_df, breadth, sectors, regime = scanner.run_scan(as_of_date=latest_date, top_n=20)
    else:
        import json
        import pandas as pd
        top_df = pd.read_csv(screener_file)
        with open(reports_dir / "market_breadth_live.json", "r", encoding="utf-8") as f:
            breadth = json.load(f)
        with open(reports_dir / "sector_rotation_live.json", "r", encoding="utf-8") as f:
            sectors = json.load(f)
        scanner = PydroidScanner(BASE_DIR)
        regime = scanner.evaluate_regime(latest_date)

    msg = format_telegram_alert(top_df, breadth, sectors, regime, latest_date)
    print("Dispatching executive alert message...")
    ok_msg = sender.send_message(msg)

    # Check for visual chart to attach
    chart_png = reports_dir / "market_overview_chart.png"
    if chart_png.exists():
        print("Dispatching market overview chart PNG...")
        sender.send_photo(chart_png, caption=f"📊 Market Overview Chart — {latest_date}")

    # Check for CSV to attach
    if screener_file.exists():
        print("Dispatching screener candidate CSV...")
        sender.send_document(screener_file, caption=f"📁 Screener Candidates — {latest_date}")

    if ok_msg:
        print(f"\n{C_GREEN}✓ Live Telegram notification dispatched successfully!{C_RESET}")
    else:
        print(f"\n{C_RED}✗ Failed to dispatch message to Telegram.{C_RESET}")

    input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def run_visuals_generator():
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_GREEN}📊 GENERATING VISUAL CHARTS & TEARSHEETS...{C_RESET}\n")

    reports_dir = BASE_DIR / "reports"
    screener_file = reports_dir / "screener_output_live.csv"
    if not screener_file.exists():
        print(f"{C_YELLOW}Running scanner to generate latest metrics...{C_RESET}")
        scanner = PydroidScanner(BASE_DIR)
        top_df, breadth, sectors, regime = scanner.run_scan(as_of_date=latest_date, top_n=20)
    else:
        import json
        import pandas as pd
        top_df = pd.read_csv(screener_file)
        with open(reports_dir / "market_breadth_live.json", "r", encoding="utf-8") as f:
            breadth = json.load(f)
        with open(reports_dir / "sector_rotation_live.json", "r", encoding="utf-8") as f:
            sectors = json.load(f)

    # Matplotlib Chart
    print("Generating Matplotlib 3-panel graphic...")
    png_path = generate_matplotlib_dashboard(breadth, sectors, top_df)
    print(f"  ✓ Exported: {png_path} ({png_path.stat().st_size:,} bytes)")

    # Plotly Tearsheet
    print("\nGenerating interactive HTML tearsheet...")
    html_path = generate_plotly_tearsheet(breadth, sectors, top_df)
    print(f"  ✓ Exported: {html_path} ({html_path.stat().st_size:,} bytes)")

    print(f"\n{C_GREEN}✓ All visual deliverables exported to reports/{C_RESET}")
    input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def run_custom_backtest_flow():
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_CYAN}💼 LIGHTWEIGHT VECTOR BACKTESTER{C_RESET}\n")

    print(f"Configure Backtest Parameters (Press Enter to accept defaults):")
    start_in = input("  1. Start Date [Default: 2020-01-01]: ").strip() or "2020-01-01"
    end_in = input(f"  2. End Date [Default: {latest_date}]: ").strip() or latest_date
    top_n_in = input("  3. Portfolio Top N [Default: 20]: ").strip() or "20"
    capital_in = input("  4. Initial Capital (₹) [Default: 1000000]: ").strip() or "1000000"

    try:
        top_n = int(top_n_in)
        capital = float(capital_in)
    except ValueError:
        print(f"{C_RED}Invalid inputs! Using defaults.{C_RESET}")
        top_n = 20
        capital = 1_000_000.0

    print(f"\n{C_YELLOW}Running simulation from {start_in} to {end_in}...{C_RESET}")
    bt = LightweightBacktester(BASE_DIR)
    t0 = time.time()
    results = bt.run(
        start_date=start_in,
        end_date=end_in,
        top_n=top_n,
        initial_capital=capital
    )
    elapsed = time.time() - t0

    print(f"\n{C_BOLD}{'=' * 68}{C_RESET}")
    print(f"{C_BOLD} BACKTEST PERFORMANCE SUMMARY ({start_in} to {end_in}){C_RESET}")
    print(f"{C_BOLD}{'=' * 68}{C_RESET}")
    print(f"  Strategy CAGR:       {C_GREEN}{results['cagr_pct']:+.2f}%{C_RESET}")
    print(f"  Benchmark CAGR:      {results['benchmark_cagr_pct']:+.2f}%")
    print(f"  Excess CAGR:         {C_BOLD}{results['excess_cagr_pct']:+.2f}%{C_RESET}")
    print(f"  Sharpe Ratio:        {results['sharpe_ratio']:.2f}")
    print(f"  Sortino Ratio:       {results['sortino_ratio']:.2f}")
    print(f"  Calmar Ratio:        {results['calmar_ratio']:.2f}")
    print(f"  Max Drawdown:        {C_RED}{results['max_drawdown_pct']:.2f}%{C_RESET}")
    print(f"  Total Trades:        {results['total_trades']}")
    print(f"  Trade Win Rate:      {results['win_rate_pct']:.1f}%")
    print(f"  Final Equity:        ₹{results['final_equity']:,.2f}")
    print(f"  Computation Time:    {elapsed:.2f}s")
    print(f"{C_BOLD}{'=' * 68}{C_RESET}")
    print(f"✓ Results saved to reports/backtest_results.json")

    input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def run_tdd_suite():
    clear_screen()
    latest_date = get_latest_date()
    print_banner(latest_date)
    print(f"\n{C_BOLD}{C_YELLOW}🛡️ RUNNING TDD TEST & INTEGRITY SUITE (TESTS 01 - 04)...{C_RESET}\n")

    test_scripts = [
        "01_test_environment.py",
        "02_test_data_engine.py",
        "03_test_scanner.py",
        "04_test_visuals.py",
    ]

    all_passed = True
    for ts in test_scripts:
        script_path = BASE_DIR / "tests" / ts
        print(f"\n{C_BOLD}▶ Running {ts}...{C_RESET}")
        ret = os.system(f'"{sys.executable}" "{script_path}"')
        if ret != 0:
            all_passed = False
            print(f"{C_RED}✗ Test {ts} returned exit code {ret}{C_RESET}")
            break

    print(f"\n{C_BOLD}{'=' * 68}{C_RESET}")
    if all_passed:
        print(f"{C_BOLD}{C_GREEN} 🎉 ALL TDD INTEGRITY TESTS PASSED SUCCESSFULLY! (100% CERTIFIED){C_RESET}")
    else:
        print(f"{C_BOLD}{C_RED} ❌ TDD TEST SUITE ENCOUNTERED FAILURES.{C_RESET}")
    print(f"{C_BOLD}{'=' * 68}{C_RESET}")

    input(f"\n{C_GRAY}Press Enter to return to menu...{C_RESET}")


def main_menu():
    while True:
        clear_screen()
        latest_date = get_latest_date()
        print_banner(latest_date)

        print(f"{C_BOLD} OPERATIONAL MENU:{C_RESET}\n")
        print(f"  {C_GREEN}[1]{C_RESET} 🚀  Run Weekly Momentum Scanner (Full Suite)")
        print(f"  {C_BLUE}[2]{C_RESET} 📱  Preview Telegram Alert (Terminal Preview)")
        print(f"  {C_MAGENTA}[3]{C_RESET} ⚡  Dispatch Live Telegram Alert (Text + Charts)")
        print(f"  {C_CYAN}[4]{C_RESET} 📊  Generate Visual Charts & Tearsheets (Plotly/Matplotlib)")
        print(f"  {C_YELLOW}[5]{C_RESET} 💼  Run Lightweight Custom Backtester")
        print(f"  {C_GREEN}[6]{C_RESET} 🛡️   Run TDD Diagnostics & Integrity Suite (01–04)")
        print(f"  {C_RED}[0]{C_RESET} 🚪  Exit Workstation\n")

        try:
            choice = input(f"{C_BOLD}Select Option [0-6]: {C_RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            break

        if choice == "1":
            run_scanner_flow()
        elif choice == "2":
            run_telegram_preview()
        elif choice == "3":
            run_telegram_dispatch()
        elif choice == "4":
            run_visuals_generator()
        elif choice == "5":
            run_custom_backtest_flow()
        elif choice == "6":
            run_tdd_suite()
        elif choice == "0":
            print(f"\n{C_CYAN}Goodbye! Project MIP Pydroid 3 session ended.{C_RESET}\n")
            break
        else:
            print(f"{C_RED}Invalid option!{C_RESET}")
            time.sleep(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Project MIP Pydroid 3 Workstation")
    parser.add_argument("--option", type=int, choices=[1, 2, 3, 4, 5, 6], help="Run option directly without menu")
    args = parser.parse_args()

    if args.option == 1:
        run_scanner_flow(interactive=False)
    elif args.option == 2:
        run_telegram_preview()
    elif args.option == 3:
        run_telegram_dispatch()
    elif args.option == 4:
        run_visuals_generator()
    elif args.option == 5:
        run_custom_backtest_flow()
    elif args.option == 6:
        run_tdd_suite()
    else:
        main_menu()
