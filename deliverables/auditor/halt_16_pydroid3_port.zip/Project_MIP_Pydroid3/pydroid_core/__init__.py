"""
Project MIP: Standalone Pydroid 3 Quantitative Engine
Zero-compiler, mobile-native quantitative architecture.
"""

__version__ = "1.0.0-pydroid3"
