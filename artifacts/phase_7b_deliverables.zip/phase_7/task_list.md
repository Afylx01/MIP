# Task List: Phase 7A — Institutional Due-Diligence & Verification Suite (Gates 1–10)

## Environment Context
- Device: Samsung Galaxy S23 (Termux PRoot Ubuntu Linux aarch64)
- Engine: Ubuntu system python3 with standard debian/pip packages (`/usr/bin/python3`)
- Deliverables Directory: `deliverables/phase_7/`
- Standing Gate: **HALT-8A** (Mandatory pause awaiting Auditor review and verification of Gates 1–10)

## Execution Roadmap & Gates
- [x] **Task 1: Engine Configuration & Benchmark Ingestion**:
  - [x] Implement `deliverables/phase_7/scripts/init_phase7_engine.py`
  - [x] Ingest `data/adjusted_bhavcopy_max_2007_2026.parquet` (2,137,630 bars across 1,039 symbols, 2007-01-02 to 2026-08-31)
  - [x] Ingest `data/benchmarks/NIFTY_50.csv`, `data/benchmarks/NIFTY_100.csv`, and `index__NSEI_cache.pkl`
  - [x] Synthesize continuous NIFTY 500 benchmark proxy with 100% calendar alignment across all 4,857 trading sessions
  - [x] Export `deliverables/phase_7/data_csv/nifty_500_benchmark_proxy.csv` (4,857 rows, 0 nulls)
  - [x] Validate baseline engine execution readiness in `indian_backtest`

- [x] **Task 2: Data Integrity & Survivorship Verification (Gates 1, 2, 3, 4)**:
  - [x] Implement `deliverables/phase_7/scripts/test_data_integrity.py`
  - [x] **Gate 1 (Point-in-Time Universe Audit)**: Audit all 236 monthly rebalance snapshots (2007–2026); verify 0 modern IPO leakages (PASS, 100.0%)
  - [x] **Gate 2 (Delisting & Survivorship Invariant)**: Verify graveyard constituents (DHFL, RCOM, UNITECH, GTLINFRA, ABAN) retain full history and terminal liquidation without purging (PASS, 100.0%)
  - [x] **Gate 3 (Look-Ahead Bias Proof)**: Mathematically prove EOD t signal -> t+1 Open fill across 1,080 trades with 0 same-day fills (PASS, 100.0%)
  - [x] **Gate 4 (Corporate Action Integrity)**: Audit 1-day returns across 9 verified bonus/split dates; confirm max move 2.79% and 0 split-drop plunge artifacts (PASS, 100.0%)
  - [x] Export `deliverables/phase_7/data_csv/gates_1_4_integrity_audit.csv`

- [x] **Task 3: Execution Realism & Circuit Limit Simulation (Gates 9, 10)**:
  - [x] Implement `deliverables/phase_7/scripts/test_execution_constraints.py`
  - [x] **Gate 9 (Execution Delay & Timing Sensitivity)**:
    - Model 1 (t+1 Open): 22.97% CAGR, 45.92% Max DD, Sharpe 0.82
    - Model 2 (t+1 VWAP): 23.11% CAGR, 46.20% Max DD (Relative delta 0.61% <= 20% threshold, PASS)
    - Model 3 (t+2 Open): 24.07% CAGR, 46.80% Max DD (Excess over benchmark +12.93 pp > 0% threshold, PASS)
  - [x] **Gate 10 (Circuit Limit & Tradability Guard)**:
    - Model upper and lower daily price bands across 1,140 intended rebalance orders
    - 1,132 orders fully executed on scheduled date (99.30% executable >= 80% threshold, PASS)
    - Upper circuit BUY blocks: 3; Lower circuit SELL blocks: 5
  - [x] Export `deliverables/phase_7/data_csv/gates_9_10_execution_constraints.csv`

- [x] **Task 4: Transaction Cost & Slippage Stress Matrix (Gates 5, 6, 7, 8)**:
  - [x] Implement `deliverables/phase_7/scripts/test_cost_sensitivity.py`
  - [x] **Gate 5 (Base Institutional Cost Model)**: Net CAGR 22.97% vs Benchmark 11.14% (Excess +11.83 pp >= +4.0 pp threshold, PASS)
  - [x] **Gate 6 (2x Cost Stress Test)**: Double friction and slippage; Net CAGR 21.42% (Excess +10.28 pp >= +2.0 pp threshold, PASS)
  - [x] **Gate 7 (3x Cost Stress Test)**: Triple friction and slippage; Net CAGR 19.90% (Excess +8.76 pp > 0.0 pp threshold, PASS)
  - [x] **Gate 8 (Slippage Sensitivity Ladder)**:
    - 0.10% slippage: 22.97% CAGR, 45.92% Max DD
    - 0.25% slippage: 21.23% CAGR, 47.55% Max DD
    - 0.50% slippage: 18.40% CAGR, 50.15% Max DD (> benchmark 11.14%, PASS)
    - 1.00% slippage: 12.98% CAGR, 54.92% Max DD
    - Max DD increase across ladder: 9.00 pp (< 10 pp threshold, PASS)
  - [x] Export required Phase 7 standardized data tables:
    - `data_csv/daily_equity_curves.csv` (2,636 trading days)
    - `data_csv/monthly_returns.csv` (128 months)
    - `data_csv/trade_log.csv` (1,134 trades)
    - `data_csv/monthly_holdings_snapshots.parquet` (2,270 rows)
    - `data_csv/gates_5_8_cost_stress_matrix.csv`
    - `data_csv/gates_1_to_10_summary.csv` (all 10 gates certified PASS)

- [x] **Task 5: Compilation of Phase 7A Deliverables & Standing Gate HALT-8A**:
  - [x] Author comprehensive executive tearsheet and audit digest in `deliverables/phase_7/DIGEST.md`
  - [x] Generate `deliverables/phase_7/EVIDENCE_INDEX.tsv` and `deliverables/phase_7/SHA256SUMS.txt`
  - [x] Package bundle into `artifacts/phase_7a_deliverables.zip` and `/sdcard/Documents/deliverables/phase_7a_deliverables.zip`
  - [x] Dispatch Telegram notifications and deliverables alert
  - [x] **Standing Gate HALT-8A: Mandatory Pause for Auditor Review and Ruling on Gates 1–10 (CLEARED & ACCEPTED in PHASE_7A_RULING.md)**

## Phase 7B: Statistical Rigor, Parameter Plateau & Walk-Forward Analysis (Gates 11–16)
- [x] **Task 1: In-Sample vs. Out-of-Sample Split Audit (Gate 11)**:
  - [x] Implement `deliverables/phase_7/scripts/test_is_oos_split.py`
  - [x] Evaluate In-Sample (2007–2015): Strat CAGR 24.72% vs Bench 8.09% (Excess: +16.63 pp, Sharpe: 1.04)
  - [x] Evaluate Out-of-Sample (2016–2026): Strat CAGR 22.97% vs Bench 11.14% (Excess: +11.83 pp, Sharpe: 0.82)
  - [x] Verify Rule R-3 accounting identity residual 0.00 to the paisa
  - [x] Export `deliverables/phase_7/data_csv/gate11_is_oos_results.csv` (STRICT PASS)

- [x] **Task 2: Walk-Forward Rolling Analysis (Gate 12)**:
  - [x] Implement `deliverables/phase_7/scripts/test_walk_forward.py`
  - [x] Evaluate 14 rolling 5y-train / 1y-test windows across 2012–2026
  - [x] 10 of 14 winning OOS test windows (71.4% win rate >= 70.0% threshold)
  - [x] Median annual excess return: +9.05 percentage points (> +3.00 pp threshold)
  - [x] Mean annual excess return: +17.69 percentage points
  - [x] Export `deliverables/phase_7/data_csv/gate12_walk_forward_matrix.csv` (STRICT PASS)

- [x] **Task 3: Multi-Dimensional Parameter Plateau Grid (Gate 14)**:
  - [x] Implement `deliverables/phase_7/scripts/test_parameter_plateau.py`
  - [x] Evaluate 54 discrete parameter sets across 2016–2026:
    - Retracement Factor: [0.85, 0.80, 0.75]
    - EMA Trend Filter: [150, 200, 250] days
    - Ranking Lookback: [126, 189, 252] days
    - Portfolio Size: [15, 20] stocks
  - [x] 54 of 54 combinations beat benchmark CAGR by >= +3.0 pp (100.0% >= 70.0% threshold)
  - [x] Strategy CAGR range: 20.19% to 25.80% (Excess range: +9.05 pp to +14.66 pp)
  - [x] Export `deliverables/phase_7/data_csv/gate14_parameter_plateau_grid.csv` (STRICT PASS)

- [x] **Task 4: Rebalance-Date Sensitivity Evaluation (Gate 15)**:
  - [x] Implement `deliverables/phase_7/scripts/test_rebalance_date_sensitivity.py`
  - [x] Evaluate 5 distinct monthly execution days: 1st (22.97%), 5th (27.32%), 10th (27.89%), 15th (22.98%), Last (20.07%)
  - [x] Average excess CAGR across dates: +13.11 percentage points (> +3.00 pp threshold)
  - [x] Standard deviation of excess returns: 3.29 percentage points (< 4.00 pp threshold)
  - [x] Export `deliverables/phase_7/data_csv/gate15_rebalance_date_sensitivity.csv` (STRICT PASS)

- [x] **Task 5: Universe Segment Breadth & Paper Trading Calibration (Gates 16 & 13)**:
  - [x] Implement `deliverables/phase_7/scripts/test_universe_and_paper_trading.py`
  - [x] **Gate 16 (Universe Breadth)**:
    - Evaluate NIFTY 50 (9.65%), NIFTY Next 50 (9.87%), NIFTY Midcap 150 (22.18%), NIFTY Smallcap 250 (31.51%), NIFTY 500 (22.97%)
    - 3 of 5 universes beat benchmark by >= +3.0 pp (Mid +11.04 pp, Small +20.37 pp, N500 +11.83 pp) (STRICT PASS)
    - Export `deliverables/phase_7/data_csv/gate16_universe_sensitivity.csv`
  - [x] **Gate 13 (Simulated Paper Trading Calibration)**:
    - Evaluate recent 12m forward calibration (2025-09-01 to 2026-08-31)
    - Theoretical Ideal CAGR: 21.78% | Executed Model CAGR: 20.46%
    - Execution tracking error: 1.32 percentage points (< 5.0 pp threshold, PASS)
    - Frictional drag: 25.6 bps (<= 150.0 bps threshold, PASS)
    - Export `deliverables/phase_7/data_csv/gate13_paper_trading_calibration.csv`

- [x] **Task 6: Master Compilation & Deliverables Packaging**:
  - [x] Export `deliverables/phase_7/data_csv/gates_11_16_summary.csv` (all 6 gates certified PASS)
  - [x] Author `deliverables/phase_7/DIGEST_PHASE_7B.md`
  - [x] Regenerate `deliverables/phase_7/EVIDENCE_INDEX.tsv` and `deliverables/phase_7/SHA256SUMS.txt`
  - [x] Package deliverables into `artifacts/phase_7b_deliverables.zip` and `/sdcard/Documents/deliverables/phase_7b_deliverables.zip`
  - [x] Dispatch Telegram completion alert
  - [x] **Standing Gate HALT-8B: Mandatory Pause for Auditor Review and Ruling on Gates 11–16 (CLEARED & CLOSED)**
