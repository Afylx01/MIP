#!/usr/bin/env python3
"""
deliverables/phase_7/scripts/generate_evidence_index.py
Phase 7A — EVIDENCE_INDEX.tsv and SHA256SUMS Generator

Generates cryptographic checksums and evidence manifests for Phase 7A deliverables.
"""

import hashlib
from pathlib import Path

BASE_DIR = Path("/storage/emulated/0/Documents/Project MIP")
DELIV_DIR = BASE_DIR / "deliverables/phase_7"

def get_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def what_it_proves(rel_path: str) -> str:
    p = rel_path
    if "PHASE_7A_RULING.md" in p:
        return "Final Auditor Ruling formally accepting Gates 1-10 and clearing Standing Gate HALT-8A"
    if "NEXT_TASK.md" in p:
        return "Phase 7 active directive specifying the 32-Gate Institutional Framework and Phase 7A roadmap"
    if "DIGEST.md" in p:
        return "Phase 7A Executive Digest and verification tearsheet across Gates 1 to 10"
    if "task_list.md" in p:
        return "Phase 7A execution roadmap tracking Tasks 1-5 with Standing Gate HALT-8A open"
    if "SHA256SUMS.txt" in p:
        return "Cryptographic SHA-256 manifest of all Phase 7A deliverables"
    if "data_csv/nifty_500_benchmark_proxy.csv" in p:
        return "Synthesized continuous NIFTY 500 benchmark proxy with 100% calendar alignment across 4,857 trading sessions"
    if "data_csv/gates_1_4_integrity_audit.csv" in p:
        return "Verification records for Gates 1-4: point-in-time universe, graveyard scrip liquidation, lookahead proof, split adjustments"
    if "data_csv/gates_9_10_execution_constraints.csv" in p:
        return "Verification records for Gates 9-10: execution timing models (Open, VWAP, t+2) and circuit limit tradability guard"
    if "data_csv/gates_5_8_cost_stress_matrix.csv" in p:
        return "Transaction friction stress matrix (1x, 2x, 3x) and slippage sensitivity ladder (0.10% to 1.00%)"
    if "data_csv/daily_equity_curves.csv" in p:
        return "Standardized daily equity curves, cash balances, invested capital, benchmark values, and drawdowns (2,636 days)"
    if "data_csv/monthly_returns.csv" in p:
        return "Standardized monthly returns table with strategy return, benchmark return, and excess return (128 months)"
    if "data_csv/trade_log.csv" in p:
        return "Comprehensive itemized trade log with signal dates, execution dates, prices, friction costs, and exit reasons (1,134 trades)"
    if "data_csv/monthly_holdings_snapshots.parquet" in p:
        return "Monthly rebalance portfolio holdings snapshots detailing constituent ranks, share counts, market values, and weights"
    if "data_csv/gates_1_to_10_summary.csv" in p:
        return "Master consolidated compliance summary table certifying PASS status across Gates 1 to 10"
    if "raw/init_phase7_engine.log" in p:
        return "Raw stdout execution log of Task 1 engine configuration and benchmark synthesis"
    if "raw/test_data_integrity.log" in p:
        return "Raw stdout execution log of Task 2 data integrity and survivorship audit (Gates 1-4)"
    if "raw/test_execution_constraints.log" in p:
        return "Raw stdout execution log of Task 3 execution models and circuit limits (Gates 9-10)"
    if "raw/test_cost_sensitivity.log" in p:
        return "Raw stdout execution log of Task 4 cost stress matrix and portfolio deliverables generation"
    if "scripts/init_phase7_engine.py" in p:
        return "Engine configuration and continuous benchmark proxy ingestion builder script"
    if "scripts/test_data_integrity.py" in p:
        return "Data integrity, graveyard survivorship, lookahead bias, and corporate action audit script"
    if "scripts/test_execution_constraints.py" in p:
        return "Execution delay models and exchange circuit limit simulation script"
    if "scripts/test_cost_sensitivity.py" in p:
        return "Cost stress test, slippage ladder, and standardized portfolio deliverable exporter script"
    if "scripts/generate_evidence_index.py" in p:
        return "Phase 7A evidence manifest and cryptographic checksum generator script"
    if "data/adjusted_bhavcopy_max_2007_2026.parquet" in p:
        return "Certified maximum Bhavcopy ground-truth dataset (2007-2026, 2,137,630 bars across 1,039 symbols)"
    if "data/symbol_map.parquet" in p:
        return "Point-in-time symbol mapping table providing active constituent resolution (1,614 scrips)"
    if "data/benchmarks/NIFTY_50.csv" in p:
        return "Official NIFTY 50 index daily historical series"
    if "data/benchmarks/NIFTY_100.csv" in p:
        return "Official NIFTY 100 index daily historical series providing pre-2007 warmup coverage"
    if "data/verification/survivorship_graveyard.csv" in p:
        return "Audited survivorship graveyard register containing 1,209 vanished / delisted equities"
    return "Artifact supporting Phase 7A institutional verification"

def main():
    rows = []
    files = []

    # 1. Deliverables directory files
    for f in sorted(DELIV_DIR.glob("**/*")):
        if f.is_file() and f.name not in ["EVIDENCE_INDEX.tsv", "SHA256SUMS.txt"]:
            files.append(f)

    # 2. Core data dependencies
    for f in [
        BASE_DIR / "data/adjusted_bhavcopy_max_2007_2026.parquet",
        BASE_DIR / "data/symbol_map.parquet",
        BASE_DIR / "data/benchmarks/NIFTY_50.csv",
        BASE_DIR / "data/benchmarks/NIFTY_100.csv",
        BASE_DIR / "data/verification/survivorship_graveyard.csv"
    ]:
        if f.exists() and f.is_file():
            files.append(f)

    for f in sorted(files, key=lambda x: str(x.relative_to(BASE_DIR))):
        rel_p = str(f.relative_to(BASE_DIR))
        size = f.stat().st_size
        sha = get_sha256(f)
        desc = what_it_proves(rel_p)
        rows.append(f"{rel_p}\t{size}\t{sha}\t{desc}")

    out_tsv = DELIV_DIR / "EVIDENCE_INDEX.tsv"
    with open(out_tsv, "w", encoding="utf-8") as out:
        out.write("path\tbytes\tsha256\twhat_it_proves\n")
        for r in rows:
            out.write(r + "\n")

    print(f"Generated {out_tsv} ({out_tsv.stat().st_size:,} bytes, {len(rows)} entries).")

    # 3. Generate SHA256SUMS.txt for all files in deliverables/phase_7/
    sha_lines = []
    for f in sorted(DELIV_DIR.glob("**/*")):
        if f.is_file() and f.name != "SHA256SUMS.txt":
            rel_p = str(f.relative_to(DELIV_DIR))
            sha = get_sha256(f)
            sha_lines.append(f"{sha}  {rel_p}")

    out_sha = DELIV_DIR / "SHA256SUMS.txt"
    with open(out_sha, "w", encoding="utf-8") as out:
        for line in sha_lines:
            out.write(line + "\n")

    print(f"Generated {out_sha} ({out_sha.stat().st_size:,} bytes, {len(sha_lines)} checksums).")

if __name__ == "__main__":
    main()
