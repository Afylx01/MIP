# Phase 5.5 Task List: Point-in-Time Index Membership & Network Viability

## Environment Context
- Device: Samsung Galaxy S23 (Termux PRoot Ubuntu Linux aarch64)
- Engine: Ubuntu system python3 with standard debian packages (no Termux python modules)
- Deliverables Directory: `deliverables/gate3/`

## Phase 5.5 Roadmap & Gates
- [x] Gate 0: Inventory & Bulletin Availability (`gate0_inventory.py`) — COMPLETE (reference only)
- [x] Gate 1: Parse & Date Validation (`gate1_parse_validate.py`) — COMPLETE (reference only)
- [x] Gate 2: Initial Symbol Map & Report (`gate2_build_symbol_map.py`) — COMPLETE (reference only)
- [x] Gate 2b: Symbol Map Evidence Hardening — COMPLETE (reference only)
- [x] Gate 2c: Flag Fixes, Price-Data Audit, Backtestable-Window Report — COMPLETE (reference only)
- [ ] HALT-1b: Auditor review of Gate 2c deliverables (UNTICKED, OPEN)
- [x] Phase 5.5.A-1 Gate 0: Prerequisite Inventory (Q1–Q5) (`gate0.txt`, `gate0_inventory.py`)
- [x] Phase 5.5.A-1 Gate 1: Network Burst Test (`burst_probe.py`, `probe_content_validate.py`, `burst_log.csv`, `burst_summary.csv`)
- [x] HALT-1b-P-1: Auditor review of Phase 5.5.A-1 — ACCEPTED
- [x] Phase 5.5.A-2 Gate 0: CA Endpoint Discovery (`gate0_discovery.txt`, `gate0_ca_discovery.py`)
- [x] Phase 5.5.A-2 Gate 1: CA Fetch (`gate1_fetch.txt`, `ca_calendar_raw.parquet`, Bhavcopy samples)
- [x] Phase 5.5.A-2 Gate 2: Schema and Sanity (`gate2_sanity.txt`, `gate2_schema_sanity.py`)
- [x] Phase 5.5.A-2 Gate 3: Adjuster Built (`gate3_smoke_test.txt`, `adjust_prices.py`, `test_adjust_prices.py`)
- [x] Phase 5.5.A-2 Gate 4: Adjuster Unit Test on Real Data (`gate4_unit_test.txt`, `gate4_unit_test.py`)
- [x] HALT-1b-P-2: Auditor review of Phase 5.5.A-2 — ACCEPTED (A2_RULING.md)
- [x] Phase 5.5.A-3 Gate 0: Snapshot & Universe Prerequisite Audit
- [x] Phase 5.5.A-3 Gate 1: Bhavcopy Acquisition & Raw Price Ingestion
- [x] Phase 5.5.A-3 Gate 2: Corporate Action Adjustment Execution
- [x] Phase 5.5.A-3 Gate 3: Joint Coverage Re-Measurement
- [x] Phase 5.5.A-3 Gate 4: Acceptance Ruling & Deliverable Bundle Compilation
- [x] HALT-1b-P-3: Auditor review of Phase 5.5.A-3 — REJECT (A3_RULING.md)
- [x] Phase 5.5.M-1 Gate 0: NIFTY500 Pending Scrip Triage & Impact Ranking — COMPLETE
- [x] Phase 5.5.M-1 Gate 1: High-Confidence Tier Vetting & Application — COMPLETE
- [x] Phase 5.5.M-1 Gate 2: Medium-Confidence & Corporate Rename Resolution — COMPLETE
- [x] Phase 5.5.M-1 Gate 3: Local Price Extraction from 1,154 Cached Bhavcopies — COMPLETE
- [x] Phase 5.5.M-1 Gate 4: Coverage Re-Measurement & PASS Threshold Validation — COMPLETE (PASS: 86.25%)
- [ ] HALT-1b-M-1: Auditor review of Phase 5.5.M-1 (UNTICKED, OPEN)
- [x] Gate 3: Corrections Proposal (`data/corrections.parquet`) — PROPOSED
- [ ] HALT-2: Stop and wait for user approval of corrections (UNTICKED, OPEN)
- [ ] Gate A: Coverage Map (post-approval)
- [ ] Gate B: Snapshot Sanity (NIFTY500 490-510 check)
- [ ] Gate C: Continuity (zero orphans/duplicates post-corrections)
- [ ] Gate D: Reconstruct, Re-Run, Price Coverage (MIP-Return-10Y comparison)
- [ ] Gate E: Round-Trip Invariance (Forward vs Backward replay)
- [ ] Gate F: Reproducibility & Truncation Clamping
